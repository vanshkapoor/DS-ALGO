#include <iostream>
#include "LinkedSortedList.h"
#include "LinkedSortedList.cpp"

using namespace std;

int main()
{
    string lastval;
    LinkedSortedList *obj = new LinkedSortedList();
    obj->check();
    obj->insert("dbca");
    obj->insert("abcd");
    obj->insert("acbd");
    obj->insert("vansh");
    obj->print();
    obj->getlast(lastval);

    cout<<lastval<<endl;;
    obj->print();
    cout << endl;
    obj->getlast(lastval);
    obj->print();
    cout << endl;
    obj->getlast(lastval);
    obj->print();
    cout << endl;
    obj->getlast(lastval);
    obj->print();

    LinkedSortedList *obj2 = new LinkedSortedList();
    obj2->insert("a");
    obj2->insert("v");
    obj2->insert("c");
    obj2->insert("b");
    cout<<endl;
    obj2->print();
    LinkedSortedList * res= MergeLinkedSortedList();
    cout<<endl;
    res->print();
    return 0;
}
